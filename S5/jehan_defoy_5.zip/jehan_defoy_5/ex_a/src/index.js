import AppLoader from 'components/App/AppLoader'
import ReactDOM from 'react-dom'

ReactDOM.render(
  <AppLoader />,
  document.getElementById('root')
)