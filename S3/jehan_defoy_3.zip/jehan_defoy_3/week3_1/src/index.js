import ReactDOM from 'react-dom'
import Loading from './components/Loading/Loading'

ReactDOM.render(
  <Loading />, 
  document.getElementById('root')
)