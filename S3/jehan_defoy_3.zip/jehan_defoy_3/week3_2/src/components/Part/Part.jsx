import React from "react";

const Part = ({name,exercices}) => {
    return(
        <p>{name} {exercices}</p>
    )
}

export default Part